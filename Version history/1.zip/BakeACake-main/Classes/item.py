class Item:
    def __init__(self):
        self.Name = ''
        self.Rarity = ''
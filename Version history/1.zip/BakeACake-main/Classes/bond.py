"""The player will have a random amount of social bonds at the start of the game. 
Each will be revealed when the player gains an obligation to their bond. (3 to 8 people, 
each have a ‘perceived opinion’ stat which oscillates between -100 and 100)"""

class Bond:
    def __init__(self):
        pass
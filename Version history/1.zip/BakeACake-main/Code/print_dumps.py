def Intro():
    print()
    print('Welcome to "Bake a Cake."')
    print('----------------------------')
    print("You have decided to bake a cake from scratch. It's something you've always wanted to try but never got around to.")
    print()
    print("How will you begin?")
    print('----------------------------')